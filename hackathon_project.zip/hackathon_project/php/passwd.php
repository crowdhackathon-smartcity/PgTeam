<?php 
$db = new mysqli("johnny.heliohost.org", "lazaros_1", "killbill1997", "lazaros_My_Db");
mysqli_set_charset($db, 'utf8');
if (mysqli_connect_errno()) {
 echo 'Connect failed:'; //this will print out the error while connecting to MySQL, if any
}
$var2=$_POST['name'];
$var3=$_POST['surname'];
$var4=$_POST['AFM'];
$var5=$_POST['username'];
$var6=$_POST['old_passwd'];
$p2=$_POST['new_password_1'];
$var1=$db->prepare("SELECT * FROM Citizens WHERE Name=? AND surname=? 
and TRN=? AND Username=? AND Password=? ");
$var1->bind_param('sssss',$var2,$var3,$var4,$var5,$var6);
$var1->execute();
if (empty($var1)){
	echo "Back to the login page";
}
else {
	if ($_POST['new_password_1']!=$_POST['new_password_2']){
		echo "Your new passwords dont match";
	}
	else{
		$d=$db->prepare('UPDATE Citizens SET password=? WHERE Name=? AND Surname=? 
        and TRN=? AND Username=? AND Password=?');
		$d->bind_param('ssssss',$p2,$var2,$var3,$var4,$var5,$var6);
		$d->execute();
		$d="UPDATE Citizens SET Password='$p2' where Name=$var2 AND Surname=$var3 
        and TRN=$var4 AND Username=$var5 AND Password=$var6"; 
		if($db->query($d)===TRUE){
			echo "Updated successfully";
		}
		else{
		 echo "Failure";
		}
	}
}
$var1->close();
$db->close();
?>