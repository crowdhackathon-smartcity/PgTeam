<?php
$db = new mysqli("johnny.heliohost.org", "lazaros_1", "killbill1997", "lazaros_My_Db");
mysqli_set_charset($db, "utf8");
if (mysqli_connect_errno()) {
 echo "Connect failed:"; //this will print out the error while connecting to MySQL, if any
}
else{
$resource = $db->query('SELECT * FROM Citizens');
while ( $rows = $resource->fetch_assoc() ) {
    print_r($rows);//echo "{$row['field']}";
    echo "<br>";
}
$resource->free();
$db->close();
}
?>
